
import sys

print ('Quantidade de argumentos:', len(sys.argv), 'argumentos.')
print ('Lista de argumentos:', sys.argv)
print ('Argumento 0 sys.argv[0]:', sys.argv[0])
print ('Argumento 1 sys.argv[1]:', sys.argv[1])
print ('Argumento 2 sys.argv[2]:', sys.argv[2])
print ('Argumento 3 sys.argv[3]:', sys.argv[3])
print ('Argumento 4 sys.argv[4]:', sys.argv[4])